export interface Ticket {
    ticketId: string;
    journey: any; // Replace with the correct type
    user: any; // Replace with the correct type
  }