export class Journey_Route {
    leaving_form:string;
    going_to:string;
    date:string;
}